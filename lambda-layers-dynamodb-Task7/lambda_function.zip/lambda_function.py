import boto3
import csv
import os

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['crud-table'])

def lambda_handler(event, context):
    with open('/opt/data.csv', 'r') as csvfile:
        csvreader = csv.DictReader(csvfile)
        for row in csvreader:
            table.put_item(Item=row)
    return {
        'statusCode': 200,
        'body': 'Data inserted successfully'
    }
